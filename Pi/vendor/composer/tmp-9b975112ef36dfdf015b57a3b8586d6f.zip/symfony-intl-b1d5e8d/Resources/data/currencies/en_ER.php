<?php

return [
    'Names' => [
        'ERN' => [
            'Nfk',
            'Eritrean Nakfa',
        ],
    ],
];
