<?php

return [
    'Names' => [
        'DKK' => [
            'kr.',
            'DKK',
        ],
        'EUR' => [
            '€',
            'euro',
        ],
    ],
];
