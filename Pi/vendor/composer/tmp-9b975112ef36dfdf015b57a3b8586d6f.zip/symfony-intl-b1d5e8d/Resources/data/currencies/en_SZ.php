<?php

return [
    'Names' => [
        'SZL' => [
            'E',
            'Swazi Lilangeni',
        ],
    ],
];
