<?php

return [
    'Names' => [
        'GNF' => [
            'FG',
            'GNF',
        ],
    ],
];
