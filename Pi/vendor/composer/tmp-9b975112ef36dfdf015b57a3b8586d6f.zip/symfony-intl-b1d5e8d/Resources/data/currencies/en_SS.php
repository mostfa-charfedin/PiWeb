<?php

return [
    'Names' => [
        'GBP' => [
            'GB£',
            'British Pound',
        ],
        'SSP' => [
            '£',
            'South Sudanese Pound',
        ],
    ],
];
