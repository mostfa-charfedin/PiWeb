# Upgrade from 1.x to 2.0

## ResetPasswordHelper

- Class became `@final` in `v1.22.0`. Extending this class will not be allowed
  in version `v2.0.0`.

## ResetPasswordRemoveExpiredCommand

- Class became `@final` in `v1.22.0`. Extending this class will not be allowed
  in version `v2.0.0`.
